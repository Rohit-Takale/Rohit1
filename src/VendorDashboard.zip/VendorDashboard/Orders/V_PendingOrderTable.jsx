import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import { Button, Container, Link, Typography } from "@material-ui/core";
import clsx from "clsx";
import styled from "styled-components";
import CloudUploadIcon from "@material-ui/icons/CloudUpload";

const useStyles = makeStyles((theme) => ({
  table: {
    maxHeight: 300,
  },
  heading: {
    fontSize: 12,
    color: "#474747",
    fontWeight: "bold",
  },
  text: {
    fontSize: 12,
    color: "#474747",
  },
  td: {
    borderRight: "solid 1px #9D9999",
    borderLeft: "solid 1px #9D9999",
  },
  icon: {
    color: "#FE3131",
    fontSize: 18,
  },
}));

function createData(
  OrderNo,
  PhleboId,
  Testname,
  VEarning,
  Fees,
  Delivery,
  Gross,
  Date
) {
  return {
    OrderNo,
    PhleboId,
    Testname,
    VEarning,
    Fees,
    Delivery,
    Gross,
    Date,
  };
}

const rows = [
  createData(
    "12345",
    "PH12345",
    "Blood Test",
    1250,
    500,
    150,
    1900,
    "12-12-2012"
  ),
  createData(
    "12345",
    "PH12345",
    "Blood Test",
    1250,
    500,
    150,
    1900,
    "12-12-2012"
  ),
  createData(
    "12345",
    "PH12345",
    "Blood Test",
    1250,
    500,
    150,
    1900,
    "12-12-2012"
  ),
  createData(
    "12345",
    "PH12345",
    "Blood Test",
    1250,
    500,
    150,
    1900,
    "12-12-2012"
  ),
  createData(
    "12345",
    "PH12345",
    "Blood Test",
    1250,
    500,
    150,
    1900,
    "12-12-2012"
  ),
];

const Button2 = styled.button`
  color: #fff;
  font-family: "Roboto", sans-serif;
  padding: 0px 0px;
  width: 100px;
  height: 25px;
  cursor: pointer;
  font-size: 0.6rem;
  text-transform: uppercase;
  border-width: 0px;
  border-radius: 5px;
`;

export default function V_PendingOrderTable() {
  const classes = useStyles();
  const preventDefault = (event) => event.preventDefault();

  return (
    <TableContainer style={{ border: "0.5px solid  #474747", borderRadius: 5 }}>
      <Table
        className={(classes.table, classes.customTableContainer)}
        aria-label="simple table"
      >
        <TableHead>
          <TableRow>
            <TableCell
              style={{ backgroundColor: "FFFFFF" }}
              className={classes.heading}
            >
              Order No
            </TableCell>
            <TableCell
              style={{ backgroundColor: "FFFFFF" }}
              className={clsx(classes.heading, classes.td)}
            >
              Phlebo Id
            </TableCell>
            <TableCell
              style={{ backgroundColor: "FFFFFF", width: 80 }}
              align="center"
              className={clsx(classes.heading, classes.td)}
            >
              Test Name
            </TableCell>
            <TableCell
              style={{ backgroundColor: "FFFFFF" }}
              align="center"
              className={clsx(classes.heading, classes.td)}
            >
              V-Earning
            </TableCell>
            <TableCell
              style={{ backgroundColor: "FFFFFF" }}
              align="center"
              className={clsx(classes.heading, classes.td)}
            >
              Fees
            </TableCell>
            <TableCell
              style={{ backgroundColor: "FFFFFF" }}
              align="center"
              className={clsx(classes.heading, classes.td)}
            >
              Delivery
            </TableCell>
            <TableCell
              style={{ backgroundColor: "FFFFFF" }}
              align="center"
              className={clsx(classes.heading, classes.td)}
            >
              Goss Sale
            </TableCell>
            <TableCell
              style={{ backgroundColor: "FFFFFF" }}
              align="center"
              className={clsx(classes.heading, classes.td)}
            >
              Date
            </TableCell>

            <TableCell
              style={{ backgroundColor: "FFFFFF", width: 50 }}
              align="center"
              className={clsx(classes.heading)}
            >
              Reports
            </TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.OrderNo}>
              <TableCell align="center" className={clsx(classes.text)}>
                {row.OrderNo}
              </TableCell>
              <TableCell
                align="center"
                className={clsx(classes.td, classes.text)}
              >
                {row.PhleboId}
              </TableCell>
              <TableCell
                align="center"
                className={clsx(classes.td, classes.text)}
              >
                {row.Testname}
              </TableCell>
              <TableCell
                align="center"
                className={clsx(classes.td, classes.text)}
              >
                {row.VEarning}
              </TableCell>{" "}
              <TableCell
                align="center"
                className={clsx(classes.td, classes.text)}
              >
                {row.Fees}
              </TableCell>
              <TableCell
                align="center"
                className={clsx(classes.td, classes.text)}
              >
                {row.Delivery}
              </TableCell>
              <TableCell
                align="center"
                className={clsx(classes.td, classes.text)}
              >
                {row.Gross}
              </TableCell>{" "}
              <TableCell
                align="center"
                style={{ width: 70 }}
                className={clsx(classes.td, classes.text)}
              >
                {row.Date}
              </TableCell>
              <TableCell
                align="center"
                className={clsx(classes.td, classes.text)}
                style={{ width: 80 }}
              >
                <div style={{ display: "flex" }}>
                  <Button2 style={{ width: 50, backgroundColor: "#FE3131" }}>
                    Accept
                  </Button2>
                  <div style={{marginLeft:5}}>
                    <Button2 style={{ width: 50, backgroundColor: "#474747" }}>
                      Reject
                    </Button2>
                  </div>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
