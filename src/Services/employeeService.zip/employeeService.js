export const getDepartmentCollection = () => ([
    { id: '1', title: 'karnataka' },
    { id: '2', title: 'Maharashtra' },
    { id: '3', title: 'UP' },
    { id: '4', title: 'Delhi' },
    {id : '5', title:'Tamil Nadu'}
    
])

export const getGenderCollection = () => ([
  { id: "1", title: "Male" },
  { id: "2", title: "Female" },
  { id: "3", title: "others" },
]);

export const getCityCollection = () => [
  { id: "1", title: "Belagum" },
  { id: "2", title: "Bijapur" },
  { id: "3", title: "Dharwad" },
];


export const getMangerOwnerCollection = () => [
  { id: "1", title: "Manager" },
  { id: "2", title: "Owner" },
];


export const getSampleCollection = () => [
  { id: "1", title: "1ML" },
  { id: "2", title: "2ML" },
  { id: "3", title: "5ML" },
];


export const getTestTubeCollection = () => [
  { id: "1", title: "Red top tube" },
  { id: "2", title: "Navy blue top tube" },
  { id: "3", title: "Blue top tube " },
];

export const getTestCatagoryCollection = () => [
  { id: "1", title: "Radiology" },
  { id: "2", title: "Pathology" },
];

export const getPackageCollection = () => [
  { id: "1", title: "Package1" },
  { id: "2", title: "Package2" },
  { id: "2", title: "Package3" },
  { id: "2", title: "Package4" },
  { id: "2", title: "Package5" },
];

